package br.com.tereza.petshopapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.List;
import java.util.ArrayList;
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String NOME_BANCO = "petshop.db";
    private static final int VERSAO = 1;

    public DatabaseHelper(Context context) {
        super(context, NOME_BANCO, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String criarTabela = "CREATE TABLE IF NOT EXISTS agendamentos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "dono TEXT NOT NULL, " +
                "pet TEXT NOT NULL, " +
                "servico TEXT NOT NULL, " +
                "data TEXT NOT NULL, " +
                "hora TEXT NOT NULL);";
        db.execSQL(criarTabela);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Aqui você pode atualizar a estrutura se necessário
        db.execSQL("DROP TABLE IF EXISTS agendamentos");
        onCreate(db);
    }

    public boolean inserirAgendamento(String dono, String pet, String servico, String data, String hora) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues valores = new ContentValues();
        valores.put("dono", dono);
        valores.put("pet", pet);
        valores.put("servico", servico);
        valores.put("data", data);
        valores.put("hora", hora);

        long resultado = db.insert("agendamentos", null, valores);
        db.close();

        return resultado != -1;
    }

    public boolean existeAgendamentoMesmoHorario(String data, String hora) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM agendamentos WHERE data = ? AND hora = ?", new String[]{data, hora});
        boolean existe = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return existe;
    }

    public Cursor listarAgendamentos() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM agendamentos ORDER BY data, hora", null);
    }

    public List<Agendamento> listarAgendamentos(String filtroData, String filtroServico) {
        List<Agendamento> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM agendamentos WHERE 1=1";
        List<String> args = new ArrayList<>();

        if (filtroData != null && !filtroData.isEmpty()) {
            query += " AND data = ?";
            args.add(filtroData);
        }

        if (filtroServico != null && !filtroServico.isEmpty()) {
            query += " AND servico = ?";
            args.add(filtroServico);
        }

        Cursor cursor = db.rawQuery(query, args.toArray(new String[0]));

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String dono = cursor.getString(cursor.getColumnIndexOrThrow("dono"));
                String pet = cursor.getString(cursor.getColumnIndexOrThrow("pet"));
                String servico = cursor.getString(cursor.getColumnIndexOrThrow("servico"));
                String data = cursor.getString(cursor.getColumnIndexOrThrow("data"));
                String hora = cursor.getString(cursor.getColumnIndexOrThrow("hora"));

                lista.add(new Agendamento(id, dono, pet, servico, data, hora));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return lista;
    }

    public void excluirAgendamento(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("agendamentos", "id = ?", new String[]{String.valueOf(id)});
        db.close();
    }

}

package br.com.tereza.petshopapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ListaAgendamentosActivity extends AppCompatActivity {

    private ListView listViewAgendamentos;
    private EditText filtroData;
    private Spinner filtroServico;
    private Button btnFiltrar, btnVoltar;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_agendamentos);

        listViewAgendamentos = findViewById(R.id.listViewAgendamentos);
        filtroData = findViewById(R.id.filtroData);
        filtroServico = findViewById(R.id.filtroServico);
        btnFiltrar = findViewById(R.id.btnFiltrar);
        btnVoltar = findViewById(R.id.btnVoltar);

        db = new DatabaseHelper(this);

        // ✅ Preenche o spinner com o array de serviços
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.servicos_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        filtroServico.setAdapter(adapter);

        // ✅ Carrega todos os agendamentos inicialmente
        carregarAgendamentos(null, null);

        // ✅ Filtro ao clicar no botão
        btnFiltrar.setOnClickListener(v -> {
            String data = filtroData.getText().toString().trim();
            String servico = filtroServico.getSelectedItem() != null
                    ? filtroServico.getSelectedItem().toString()
                    : null;

            if ("Todos".equals(servico)) {
                servico = null;
            }

            carregarAgendamentos(data, servico);
        });

        // ✅ Clique para excluir
        listViewAgendamentos.setOnItemClickListener((adapterView, view, position, id) -> {
            Agendamento a = (Agendamento) adapterView.getItemAtPosition(position);

            new android.app.AlertDialog.Builder(this)
                    .setTitle("Excluir Agendamento")
                    .setMessage("Tem certeza que deseja excluir o agendamento de " + a.pet + " com " + a.dono + " em " + a.data + " às " + a.hora + "?")
                    .setPositiveButton("Sim", (dialog, which) -> {
                        db.excluirAgendamento(a.id);
                        Toast.makeText(this, "Agendamento excluído", Toast.LENGTH_SHORT).show();
                        carregarAgendamentos(filtroData.getText().toString().trim(), filtroServico.getSelectedItem().toString());
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });

        btnVoltar.setOnClickListener(v -> finish());
    }

    private void carregarAgendamentos(String data, String servico) {
        List<Agendamento> lista = db.listarAgendamentos(data, servico);

        if (lista.isEmpty()) {
            Toast.makeText(this, "Nenhum agendamento encontrad.", Toast.LENGTH_SHORT).show();
        }

        AgendamentoAdapter adapter = new AgendamentoAdapter(this, lista);
        listViewAgendamentos.setAdapter(adapter);
    }
}

package br.com.tereza.petshopapp;

public class Agendamento{
    public int id;
    public String dono;
    public String pet;
    public String servico;
    public String data;
    public String hora;

    public Agendamento(int id, String dono, String pet, String servico, String data, String hora) {
        this.id = id;
        this.dono = dono;
        this.pet = pet;
        this.servico = servico;
        this.data = data;
        this.hora = hora;
    }
}

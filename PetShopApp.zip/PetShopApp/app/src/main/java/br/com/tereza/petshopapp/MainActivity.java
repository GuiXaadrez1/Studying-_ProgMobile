package br.com.tereza.petshopapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editDono, editPet, editData, editHora;
    private Spinner spinnerServico;
    private Button btnSalvar, btnListarAgendamentos;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editDono = findViewById(R.id.editDono);
        editPet = findViewById(R.id.editPet);
        editData = findViewById(R.id.editData);
        editHora = findViewById(R.id.editHora);
        spinnerServico = findViewById(R.id.spinnerServico);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnListarAgendamentos = findViewById(R.id.btnListarAgendamentos);

        db = new DatabaseHelper(this);

        // 🚨 Preenche o Spinner com os serviços
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.servicos_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerServico.setAdapter(adapter);

        btnSalvar.setOnClickListener(v -> {
            String dono = editDono.getText().toString().trim();
            String pet = editPet.getText().toString().trim();
            String data = editData.getText().toString().trim();
            String hora = editHora.getText().toString().trim();


            // 🚫 Evita crash caso o Spinner esteja vazio
            if (spinnerServico.getSelectedItem() == null) {
                Toast.makeText(this, "Selecione um serviço", Toast.LENGTH_SHORT).show();
                return;
            }

            String servico = spinnerServico.getSelectedItem().toString();

            if (dono.isEmpty() || pet.isEmpty() || data.isEmpty() || hora.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.existeAgendamentoMesmoHorario(data, hora)) {
                Toast.makeText(this, "Já existe um agendamento neste horário!", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean ok = db.inserirAgendamento(dono, pet, servico, data, hora);
            Toast.makeText(this, ok ? "Agendamento salvo" : "Erro ao salvar", Toast.LENGTH_SHORT).show();

            if (ok) {
                editDono.setText("");
                editPet.setText("");
                editData.setText("");
                editHora.setText("");
            }
        });

        btnListarAgendamentos.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListaAgendamentosActivity.class);
            startActivity(intent);
        });
    }
}



package br.com.tereza.petshopapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class AgendamentoAdapter extends BaseAdapter {

    private final Context context;
    private final List<Agendamento> agendamentos;

    public AgendamentoAdapter(Context context, List<Agendamento> agendamentos) {
        this.context = context;
        this.agendamentos = agendamentos;
    }

    @Override
    public int getCount() {
        return agendamentos.size();
    }

    @Override
    public Object getItem(int position) {
        return agendamentos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return agendamentos.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_agendamento, parent, false);

        Agendamento agendamento = agendamentos.get(position);

        TextView textDonoPet = view.findViewById(R.id.textDonoPet);
        TextView textServico = view.findViewById(R.id.textServico);
        TextView textDataHora = view.findViewById(R.id.textDataHora);

        textDonoPet.setText(agendamento.dono + " - " + agendamento.pet);
        textServico.setText("Serviço: " + agendamento.servico);
        textDataHora.setText("Data: " + agendamento.data + " | Hora: " + agendamento.hora);


        return view;
    }


}

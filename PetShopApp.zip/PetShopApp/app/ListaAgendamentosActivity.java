package br.com.tereza.petshopapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ListaAgendamentosActivity extends AppCompatActivity {

    ListView listView;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_agendamentos);

        listView = findViewById(R.id.listViewAgendamentos);
        db = new DatabaseHelper(this);

        ArrayList<String> agendamentos = new ArrayList<>();
        Cursor c = db.listarAgendamentos();

        if (c.getCount() == 0) {
            Toast.makeText(this, "Nenhum agendamento encontrado", Toast.LENGTH_SHORT).show();
        } else {
            while (c.moveToNext()) {
                String agendamento = "ID: " + c.getInt(0) + "\n" +
                        "Dono: " + c.getString(1) + "\n" +
                        "Pet: " + c.getString(2) + "\n" +
                        "Serviço: " + c.getString(3) + "\n" +
                        "Data: " + c.getString(4) + "\n" +
                        "Hora: " + c.getString(5);
                agendamentos.add(agendamento);
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, agendamentos);
        listView.setAdapter(adapter);

        c.close();
    }
}
